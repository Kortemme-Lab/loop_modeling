This is a collection of windows batch scripts (and a python script)
to rebuild the binaries, test, and upload the binaries for public distribution
upon a commit on github.

Obviously requires that these be setup on windows
Requires an install of Windows SDK 3.5 and 4.0
Full python installs for each version with the deps

Currently supporting

26-32,26-64,27-32,27-64,33-32,33-64,34-32,34-64

Note that 33 and 34 use the 4.0 SDK, while the other suse 3.5 SDK

I installed these scripts in C:\Builds

Installed libaries in C:\Installs
