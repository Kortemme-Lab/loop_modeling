# This code is part of the Biopython distribution and governed by its
# license. Please see the LICENSE file that should have been included
# as part of this package.

"""The Bio.Nexus contains a NEXUS file parser and objects to model this data."""
